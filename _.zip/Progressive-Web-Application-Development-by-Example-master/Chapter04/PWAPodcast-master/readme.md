# PWA Podstr

The PWA Pdstr app is a demonstration application for the Packt Progressive Web Apps by Example book. It focuses demonstrating service workers and service worker caching.

