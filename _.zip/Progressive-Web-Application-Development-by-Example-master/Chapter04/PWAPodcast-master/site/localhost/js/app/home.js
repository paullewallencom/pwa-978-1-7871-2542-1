var fetchImage = document.querySelector(".fetch-image");

// fetch("https://love2dev.com/images/mountain-valley.jpg")  
//     .then(function (response) {
//         return response.blob();
//     })

// .then(function (myBlob) {

//     var objectURL = URL.createObjectURL(myBlob);

//     fetchImage.src = objectURL;

// }).catch(function (err) {   
//     console.log('CORS Fetch Error :-S', err);  
// });

// "https://love2dev.com/images/mountain-valley.jpg"
// fetch("img/mountain-valley.jpg")  
//     .then(function (response) {
//         return response.blob();
//     })

// .then(function (myBlob) {

//     var objectURL = URL.createObjectURL(myBlob);

//     fetchImage.src = objectURL;

// }).catch(function (err) {   
//     console.log('No CORS Fetch Error :-S', err);  
// });

// fetch("foo.bar")  
//     .then(function (response) {

//         response.json().then(function (data) {     
//             console.log("foo bar: ", data);
//         });   

//     }).catch(function (err) {   
//         console.log('No CORS Fetch Error :-S', err);  
//     });



