(function () {

    var myResponse = new Response({
                            "foo": "bar"
                        }, {
                            "status": 200,
                            "statusText": "Success"
                        });

    

});